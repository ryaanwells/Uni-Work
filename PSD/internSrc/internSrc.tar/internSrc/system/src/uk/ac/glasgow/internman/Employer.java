package uk.ac.glasgow.internman;

public interface Employer {

	String getName();

	String getEmailAddress();

}
