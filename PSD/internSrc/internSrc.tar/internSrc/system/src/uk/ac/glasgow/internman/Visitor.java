package uk.ac.glasgow.internman;

public interface Visitor {

	String getName();

}
