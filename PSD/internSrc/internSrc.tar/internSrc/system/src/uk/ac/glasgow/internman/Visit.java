package uk.ac.glasgow.internman;

public interface Visit {

	Visitor getVisitor();

	UoGGrade getGrade();

	String getDescription();

}
